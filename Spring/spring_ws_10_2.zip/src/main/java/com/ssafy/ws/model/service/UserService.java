package com.ssafy.ws.model.service;

import com.ssafy.ws.model.dto.User;

public interface UserService {
	 User select(String id);
}
