/*
 * Author : 문범수
 * Date : 2024-02-19
 * subject : 
 * page : https://www.acmicpc.net/problem/15650
 * main : 
 * issue : 
 * name : N과M_2.java
 * duration : m
 * no : 15649
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class N과M_2 {
	public static boolean[] visited;
	public static int[] arr;
	
	public static void main(String[] args) throws Exception {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer token = new StringTokenizer(reader.readLine());
		
		int N = Integer.parseInt(token.nextToken()); // 자연수 갯수
		int M = Integer.parseInt(token.nextToken()); // 고를 수 있는 갯수

		visited = new boolean[N];
		arr = new int[M];		
	}
	public static void dfs(int N, int M, int depth) {
		if(depth == M) {
			for(int i = 0; i < arr.length; i++) {
				System.out.println(arr[i] + " ");
			}
			System.out.println();
			return;
		}
		
		for(int i = 0; i < N; i++) {
			if(visited[i] == false) {
				visited[i] = true;
				arr[depth] = i + 1;
				dfs(N, M, depth+1);
				
				visited[i] = false;
			}
		}	
	}
}
