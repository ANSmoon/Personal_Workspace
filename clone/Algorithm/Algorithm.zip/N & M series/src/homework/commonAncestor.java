/*
 * Author : 문범수
 * Date : 2024-02-14
 * subject : Tree[Lowest Common Ancestor]
 * main : 최소 공통 조상 탐색 알고리즘
 * issue : 재귀 함수 호출 이슈
 * name : commonAncestor.java
 * duration : 250m
 * CodeNo : 1248
 */

package homework;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

// node class 생성
class Node {
	int data;
	int parent;
	int left;
	int right;

	Node() {
	};

	Node(int data) {
		this.data = data;
		this.parent = 0;
		this.left = 0;
		this.right = 0;
	}
}

public class commonAncestor {
	static Node[] nodes;
	static int ancestor;
	static int compare;
	static int depth;
	static int count;
	static boolean[] visited;

	public static void main(String[] args) throws Exception {
		// 전체 테스트 케이스 total
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

		int total = Integer.parseInt(reader.readLine());
		int index = 1;

		// 반복문 시작
//		while(index <= total) {
		// 정점 갯수 V / 간선 갯수 E / 두 정점 x, y
		StringTokenizer token = new StringTokenizer(reader.readLine());
		int V = Integer.parseInt(token.nextToken());
		int E = Integer.parseInt(token.nextToken()); // 미사용
		int x = Integer.parseInt(token.nextToken());
		int y = Integer.parseInt(token.nextToken());

		// 간선 정보 입력
		token = new StringTokenizer(reader.readLine());

		int root = 1; // root는 1로 고정

		// 부모 node가 바뀌는지 비교 변수 필요
		int parent;
		int temp = 0;

		// node 생성
		// index 1부터 시작
		Node[] nodes = new Node[V + 1];
		for (int i = 1; i <= V; i++) {
			nodes[i] = new Node(i);
		}

		while (token.hasMoreTokens()) {
			// 부모 node
			parent = Integer.parseInt(token.nextToken());
			// 자식 node
			int child = Integer.parseInt(token.nextToken());

			// tree 구현 => 자식 노드를 순차적으로 왼쪽 오른쪽에 담는다.
			// 만약 부모 node가 바뀌면 바뀐 부모 node의 왼쪽 오른쪽 자식 node에 담는다.
			if (temp != parent) {
				nodes[parent].left = child;
				temp = parent;
			} else {
				nodes[parent].right = child;
			}
			nodes[child].parent = parent;
		}
			System.out.print("#" + index + " ");
		visited = new boolean[V + 1];
		System.out.print(search(x,y,nodes,visited) + " ");
		size(nodes[search(x,y,nodes,visited)]);
//			System.out.println();
//		}
	}

	// 공통 조상 탐색 method
	// x, y를 탐색할 수 있으면 해당 node 값 반환
	static int search(int x, int y, Node[] nodes, boolean[] visited) {

		int result = 0;
		int x_p = nodes[x].parent;
		int y_p = nodes[y].parent;
		
		while(true) {
			if(nodes[x_p].parent == 0) {
				break;
			}
			if(visited[x_p]) {
				result = nodes[x_p].data;
				break;
			}
			visited[x_p] = true;
			x_p = nodes[x_p].parent;
		}
		
		while(true) {
			if(nodes[y_p].parent == 0) {
				break;
			}
			if(visited[y_p]) {
				result = nodes[y_p].data;
				break;
			}
			visited[y_p] = true;
			y_p = nodes[y_p].parent;
		}
		return result;
	}
	
	// 해당 정점에 연결된 모든 정점의 갯수
	static void size(Node node) {
		count++;
		if(node == null) {
			return;
		}
		
		size(nodes[node.left]);
		size(nodes[node.right]);
		System.out.println(count);
	}
}