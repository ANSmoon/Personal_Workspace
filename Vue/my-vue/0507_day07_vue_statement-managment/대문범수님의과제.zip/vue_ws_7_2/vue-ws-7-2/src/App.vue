<script setup>
import ProductView from './components/ProductView.vue';
</script>

<template>
    <ProductView />
</template>

<style scoped>

</style>