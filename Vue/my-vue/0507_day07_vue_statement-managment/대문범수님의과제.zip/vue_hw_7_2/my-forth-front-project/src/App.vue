<script setup>
import MainPage from '@/components/MainPage.vue'
</script>

<template>
    <MainPage />
</template>

<style scoped>
  
</style>