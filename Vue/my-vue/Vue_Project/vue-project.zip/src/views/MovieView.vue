<template>
  <div>
    <MovieList />
  </div>
</template>

<script setup>
import MovieList from '@/components/movie/MovieList.vue'
</script>

<style scoped>

</style>